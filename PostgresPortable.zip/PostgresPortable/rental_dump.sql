--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.starring DROP CONSTRAINT starring_movie_id_fkey;
ALTER TABLE ONLY public.starring DROP CONSTRAINT starring_actor_id_fkey;
ALTER TABLE ONLY public.rentals DROP CONSTRAINT rentals_copy_id_fkey;
ALTER TABLE ONLY public.rentals DROP CONSTRAINT rentals_client_id_fkey;
ALTER TABLE ONLY public.copies DROP CONSTRAINT copies_movie_id_fkey;
ALTER TABLE ONLY public.starring DROP CONSTRAINT starring_pkey;
ALTER TABLE ONLY public.rentals DROP CONSTRAINT rentals_pkey;
ALTER TABLE ONLY public.movies DROP CONSTRAINT movies_pkey;
ALTER TABLE ONLY public.employees DROP CONSTRAINT employees_pkey;
ALTER TABLE ONLY public.copies DROP CONSTRAINT copies_pkey;
ALTER TABLE ONLY public.clients DROP CONSTRAINT clients_pkey;
ALTER TABLE ONLY public.actors DROP CONSTRAINT actors_pkey;
DROP TABLE public.starring;
DROP TABLE public.rentals;
DROP TABLE public.movies;
DROP TABLE public.employees;
DROP TABLE public.copies;
DROP TABLE public.clients;
DROP TABLE public.actors;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: actors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE actors (
    actor_id SERIAL NOT NULL,
    first_name character varying,
    last_name character varying,
    birthday timestamp with time zone
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE clients (
    client_id SERIAL NOT NULL,
    first_name character varying,
    last_name character varying,
    birthday timestamp with time zone
);


--
-- Name: copies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE copies (
    copy_id SERIAL NOT NULL,
    available boolean,
    movie_id integer
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE employees (
    employee_id SERIAL NOT NULL,
    first_name character varying,
    last_name character varying,
    city character varying,
    salary real
);


--
-- Name: movies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE movies (
    title character varying NOT NULL,
    year integer NOT NULL,
    age_restriction integer,
    movie_id SERIAL NOT NULL,
    price real
);


--
-- Name: rentals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE rentals (
    rental_id SERIAL NOT NULL,
    copy_id integer NOT NULL,
    client_id integer NOT NULL,
    date_of_rental timestamp with time zone,
    date_of_return timestamp with time zone
);


--
-- Name: starring; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE starring (
    starring_id SERIAL NOT NULL,
    actor_id integer NOT NULL,
    movie_id integer NOT NULL
    
);


--
-- Data for Name: actors; Type: TABLE DATA; Schema: public; Owner: -
--
INSERT INTO actors (first_name, last_name, birthday)
VALUES
('Arnold', 'Schwarzenegger', '1947-07-30 00:00:00+01'),
('Anthony', 'Daniels', '1946-02-21 00:00:00+01'),
('Harrison', 'Ford', '1942-07-13 00:00:00+02'),
('Carrie', 'Fisher', '1956-10-21 00:00:00+01'),
('Alec', 'Guiness', '1914-04-02 00:00:00+01'),
('Peter', 'Cushing', '1913-05-26 00:00:00+01'),
('David', 'Prowse', '1944-05-19 00:00:00+02'),
('Peter', 'Mayhew', '1935-07-01 00:00:00+01'),
('Michael', 'Biehn', '1956-07-31 00:00:00+01'),
('Linda', 'Hamilton', '1956-09-26 00:00:00+01'),
('Bill', 'Murray', '1950-09-21 00:00:00+01'),
('Dan', 'Aykroyd', '1952-07-01 00:00:00+01'),
('Sigourney', 'Weaver', '1949-10-08 00:00:00+01'),
('Robert', 'De Niro', '1943-08-17 00:00:00+02'),
('Jodie', 'Foster', '1962-11-19 00:00:00+01'),
('Harvey', 'Keitel', '1939-05-13 00:00:00+01'),
('Cybill', 'Shepherd', '1950-02-18 00:00:00+01'),
('Tom', 'Berenger', '1949-05-31 00:00:00+01'),
('Willem', 'Dafoe', '1955-07-22 00:00:00+01'),
('Charlie', 'Sheen', '1965-09-03 00:00:00+01'),
('Harrison', 'Ford', '1942-07-13 00:00:00+02'),
('Emmanuelle', 'Seigner', '1966-06-22 00:00:00+01'),
('Jean', 'Reno', '1948-07-30 00:00:00+01'),
('Billy', 'Crystal', '1948-03-14 00:00:00+01'),
('Lisa', 'Kudrow', '1963-07-30 00:00:00+01'),
('Gary', 'Oldman', '1958-03-21 00:00:00+01'),
('Natalie', 'Portman', '1981-06-09 00:00:00+01'),
('Tom', 'Cruise', '1962-07-03 00:00:00+01');

--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO clients (first_name, last_name, birthday)
VALUES
('Hank', 'Hill', '1954-04-19 00:00:00+01'),
('Brian', 'Griffin', '2011-09-11 00:00:00+02'),
('Gary', 'Goodspeed', '1989-03-12 00:00:00+01'),
('Bob', 'Belcher', '1977-01-23 00:00:00+01'),
('Lisa', 'Simpson', '2012-05-09 00:00:00+02'),
('Rick', 'Sanchez', '1965-03-17 00:00:00+01');


--
-- Data for Name: copies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO copies (available, movie_id)
VALUES
('t', 1),
('f', 1),
('t', 2),
('t', 3),
('f', 3),
('t', 3),
('t', 4),
('f', 5),
('t', 6),
('f', 6),
('t', 6),
('t', 7),
('t', 7),
('f', 8),
('t', 9),
('t', 10),
('f', 10),
('t', 10),
('t', 10),
('t', 10);

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO employees (first_name, last_name, city, salary)
VALUES
('John', 'Smith', 'New York', 150),
('Ben', 'Johnson', 'New York', 250),
('Louis', 'Armstrong', 'New Orleans', 75),
('John', 'Lennon', 'London', 300),
('Peter', 'Gabriel', 'London', 100);


--
-- Data for Name: movies; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO movies (title, year, age_restriction, price)
VALUES
('Star Wars Episode IV: A New Hope', 1979, 12, 10),
('Ghostbusters', 1984, 12, 5.5),
('Terminator', 1984, 15, 8.5),
('Taxi Driver', 1976, 17, 5),
('Platoon', 1986, 18, 5),
('Frantic', 1988, 15, 8.5),
('Ronin', 1998, 13, 9.5),
('Analyze This', 1999, 16, 10.5),
('Leon: the Professional', 1994, 16, 8.5),
('Mission Impossible', 1996, 13, 8.5);

--
-- Data for Name: rentals; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO rentals (copy_id, client_id, date_of_rental, date_of_return)
VALUES
('1', '1', '2005-07-04 00:00:00+02', '2005-07-05 00:00:00+02'),
('1', '6', '2005-07-06 00:00:00+02', '2005-07-07 00:00:00+02'),
('3', '2', '2005-07-24 00:00:00+02', '2005-07-25 00:00:00+02'),
('3', '3', '2005-07-22 00:00:00+02', '2005-07-23 00:00:00+02'),
('5', '2', '2005-07-26 00:00:00+02', '2005-07-27 00:00:00+02'),
('6', '1', '2005-07-19 00:00:00+02', '2005-07-22 00:00:00+02'),
('7', '2', '2005-07-29 00:00:00+02', '2005-07-30 00:00:00+02'),
('7', '3', '2005-07-24 00:00:00+02', '2005-07-25 00:00:00+02'),
('7', '6', '2005-07-29 00:00:00+02', '2005-07-30 00:00:00+02'),
('11', '5', '2005-07-10 00:00:00+02', '2005-07-13 00:00:00+02'),
('12', '3', '2005-07-10 00:00:00+02', '2005-07-13 00:00:00+02'),
('13', '4', '2005-07-01 00:00:00+02', '2005-07-05 00:00:00+02'),
('19', '6', '2005-07-29 00:00:00+02', '2005-07-30 00:00:00+02'),
('20', '3', '2005-07-16 00:00:00+02', '2005-07-17 00:00:00+02');


--
-- Data for Name: starring; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO starring (actor_id, movie_id)
VALUES
(1, 3),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(8, 1),
(7, 1),
(9, 3),
(10, 3),
(11, 2),
(12, 2),
(13, 2),
(14, 4),
(14, 7),
(14, 8),
(15, 4),
(16, 4),
(17, 4),
(18, 5),
(19, 5),
(20, 5),
(21, 6),
(22, 6),
(23, 7),
(23, 9),
(23, 10),
(24, 8),
(25, 8),
(27, 9),
(28, 10);


--
-- Name: actors actors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY actors
    ADD CONSTRAINT actors_pkey PRIMARY KEY (actor_id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (client_id);


--
-- Name: copies copies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY copies
    ADD CONSTRAINT copies_pkey PRIMARY KEY (copy_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: movies movies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY movies
    ADD CONSTRAINT movies_pkey PRIMARY KEY (movie_id);


--
-- Name: rentals rentals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rentals
    ADD CONSTRAINT rentals_pkey PRIMARY KEY (rental_id);


--
-- Name: starring starring_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY starring
    ADD CONSTRAINT starring_pkey PRIMARY KEY (starring_id);


--
-- Name: copies copies_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY copies
    ADD CONSTRAINT copies_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rentals rentals_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rentals
    ADD CONSTRAINT rentals_client_id_fkey FOREIGN KEY (client_id) REFERENCES clients(client_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rentals rentals_copy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY rentals
    ADD CONSTRAINT rentals_copy_id_fkey FOREIGN KEY (copy_id) REFERENCES copies(copy_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: starring starring_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY starring
    ADD CONSTRAINT starring_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: starring starring_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY starring
    ADD CONSTRAINT starring_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

